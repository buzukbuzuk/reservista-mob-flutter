// Export pages
export '/pages/first/first_widget.dart' show FirstWidget;
export '/pages/authentic/authentic_widget.dart' show AuthenticWidget;
export '/pages/activation/activation_widget.dart' show ActivationWidget;
export '/pages/profile/profile_widget.dart' show ProfileWidget;
export '/pages/home/home_widget.dart' show HomeWidget;
export '/pages/details/details_widget.dart' show DetailsWidget;
export '/pages/success/success_widget.dart' show SuccessWidget;
export '/pages/booking/booking_widget.dart' show BookingWidget;
